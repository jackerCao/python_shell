Buffered pipes
==============

.. automodule:: paramiko.buffered_pipe
