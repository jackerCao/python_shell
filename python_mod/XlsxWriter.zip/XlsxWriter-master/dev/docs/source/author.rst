.. _author:

Author
======

XlsxWriter was written by John McNamara.

* `GitHub <https://github.com/jmcnamara>`_
* `Twitter @jmcnamara13 <https://twitter.com/jmcnamara13>`_
* `Coderwall <https://coderwall.com/jmcnamara>`_
* `Ohloh <https://www.ohloh.net/p/XlsxWriter/contributors/2717606196831029>`_

You can contact me at jmcnamara@cpan.org.


Sponsorship
-----------

If your company would like to sponsor a feature then let me know.


Donations
---------

If you would like to donate to the XlsxWriter project to keep it active you can
do so via
`PayPal <https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=RRZCPSL65X858>`_.

.. raw:: html

   <center>
   <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
   <input type="hidden" name="cmd" value="_s-xclick">
   <input type="hidden" name="hosted_button_id" value="RRZCPSL65X858">
   <input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
   <img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
   </form>
   </center>
