.. _ex_merge1:

Example: Merging Cells
======================

This program is an example of merging cells in a worksheet. See the
:func:`merge_range` method for more details.

.. image:: _images/merge1.png

.. literalinclude:: ../../../examples/merge1.py

