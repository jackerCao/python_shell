
This directory contains some simple tests programs for testing
performance of the XlsxWriter module.

See the perf_test.sh shell script for examples.

